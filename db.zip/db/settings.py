# config.py

# API
API_KEY = 
BASE_URL = "https://wpscan.com/api/v3"

# Neo4j
NEO4J_URI = 
NEO4J_USER = 
NEO4J_PASSWORD = 
