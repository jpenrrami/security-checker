<?php

if (!defined('ABSPATH')) {
    exit;
}

function get_current_wp_version() {
    global $wp_version;
    return $wp_version;
}