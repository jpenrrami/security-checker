<?php
namespace SecurityChecker;

use Laudis\Neo4j\ClientBuilder;

class Neo4jConnector {
    public static $client = null;

    public static function getClient() {
        if (self::$client === null) {
            // Cambiar a la nueva forma de configurar la conexión
            $uri = 'bolt://neo4j:Neo4jWPS@127.0.0.1:7687'; // Cambiar a URI correcta
            self::$client = ClientBuilder::create()
                ->withDriver('bolt', $uri)  // Usar withDriver en lugar de addConnection
                ->build();
        }
        return self::$client;
    }
}