<?php
require_once plugin_dir_path(__FILE__) . '/../Neo4jConnector.php';
use SecurityChecker\Neo4jConnector;

if (!function_exists('get_plugins')) {
    require_once ABSPATH . 'wp-admin/includes/plugin.php';
}

$client = Neo4jConnector::getClient();
$installed = get_plugins();
$active_plugins = get_option('active_plugins', []);

$vulnerable_plugins = [];
foreach ($installed as $file => $data) {
    $slug = strtolower(str_replace(' ', '-', $data['Name']));
    $version = $data['Version'];
    if ($slug === 'securitychecker') continue;

    $is_active = in_array($file, $active_plugins, true);

    $cypher = "
      MATCH (p:Plugin {slug:\$slug})-[:HAS_VULNERABILITY]->(v:Vulnerability)
      WHERE v.fixed_in IS NULL OR v.fixed_in > \$version
      RETURN count(v) AS vuln_count
    ";
    $res = $client->run($cypher, ['slug' => $slug, 'version' => $version]);
    $is_vulnerable = $res->first()->get('vuln_count') > 0;

    if (!$is_vulnerable) continue;

    $vulnerable_plugins[] = [
        'slug'       => $slug,
        'name'       => $data['Name'],
        'version'    => $version,
        'active'     => $is_active ? 'active' : 'inactive',
        'vulnerable' => 'vulnerable',
    ];
}
?>

<div class="wrap sc-wrap">
  <h2 class="sc-title">Plugins actuales con vulnerabilidades</h2>

  <div class="filter-container">
    <input type="text" id="searchInput" class="sc-search" placeholder="Buscar por nombre...">
    <select id="filterActive" class="sc-select">
      <option value="all">Todos los estados</option>
      <option value="active">Activos</option>
      <option value="inactive">Inactivos</option>
    </select>
  </div>

  <table class="sc-table" id="pluginTable">
    <thead>
      <tr>
        <th>Nombre</th>
        <th>Versión</th>
        <th>Estado</th>
        <th>Riesgo</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <?php if (empty($vulnerable_plugins)): ?>
        <tr><td colspan="5" class="sc-empty">No hay plugins vulnerables instalados.</td></tr>
      <?php else: ?>
        <?php foreach ($vulnerable_plugins as $pl): ?>
          <tr class="sc-table-row"
              data-name="<?php echo esc_attr(strtolower($pl['name'])); ?>"
              data-active="<?php echo esc_attr($pl['active']); ?>">
            <td><?php echo esc_html($pl['name']); ?></td>
            <td class="text-center"><?php echo esc_html($pl['version']); ?></td>
            <td class="text-center">
              <span class="sc-plugin-status <?php echo esc_attr('sc-active-' . $pl['active']); ?>">
                <?php echo ucfirst($pl['active']); ?>
              </span>
            </td>
            <td class="text-center">
              <span class="sc-plugin-status sc-vuln-vulnerable">
                Vulnerable
              </span>
            </td>
            <td class="text-center">
              <button class="sc-plugin-button"
                      onclick="location.href='?page=security_checker&view=plugin_view&plugin=<?php echo urlencode($pl['slug']); ?>'">
                Ver plugin
              </button>
            </td>
          </tr>
        <?php endforeach; ?>
      <?php endif; ?>
    </tbody>
  </table>

  <?php include __DIR__ . '/footer.php'; ?>
</div>

<script>
  (function(){
    const searchInput = document.getElementById('searchInput');
    const filterActive = document.getElementById('filterActive');
    const rows = document.querySelectorAll('.sc-table-row');
    const noResultsMsg = document.querySelector('.sc-empty');

    function filterTable() {
      const searchTerm = searchInput.value.toLowerCase();
      const activeVal = filterActive.value;
      let visibleCount = 0;

      rows.forEach(row => {
        const name = row.dataset.name;
        const active = row.dataset.active;

        const matchesSearch = name.includes(searchTerm);
        const matchesActive = (activeVal === 'all') || (active === activeVal);

        const show = matchesSearch && matchesActive;
        row.style.display = show ? '' : 'none';
        if (show) visibleCount++;
      });

      if (noResultsMsg) {
        noResultsMsg.style.display = visibleCount === 0 ? 'table-row' : 'none';
      }
    }

    searchInput.addEventListener('input', filterTable);
    filterActive.addEventListener('change', filterTable);

    filterTable();
  })();
</script>
