<?php
require_once plugin_dir_path(__FILE__) . '/../Neo4jConnector.php';
use SecurityChecker\Neo4jConnector;

$client = Neo4jConnector::getClient();
$current_version = get_bloginfo('version');

$query = "MATCH (w:WordPressVersion {version: \$version})
          OPTIONAL MATCH (w)-[:HAS_VULNERABILITY]->(v:Vulnerability)
          RETURN collect(v) AS vulnerabilities";

$result = $client->run($query, ['version' => $current_version]);

$all_vulnerabilities = ($result->count() > 0)
    ? $result->first()['vulnerabilities']
    : [];

$vulnerabilities = [];

function version_gte($v1, $v2) {
    return version_compare($v1, $v2, '>=');
}

foreach ($all_vulnerabilities as $vuln) {
    $props = $vuln->getProperties();
    if (empty($props['fixed_in']) || !version_gte($current_version, $props['fixed_in'])) {
        $vulnerabilities[] = $vuln;
    }
}

$types = [];
foreach ($vulnerabilities as $vuln) {
    $t = strtolower(trim($vuln->getProperties()['vuln_type'] ?? 'desconocido'));
    if ($t && !in_array($t, $types, true)) {
        $types[] = $t;
    }
}
sort($types);
?>

<div class="wrap sc-wrap">
  <h2 class="sc-title">Vulnerabilidades en la versión actual (<?php echo esc_html($current_version); ?>)</h2>
  <h4 class="sc-sub">Estas son las vulnerabilidades que están presentes únicamente por la versión de WordPress</h4>

  <div class="filter-container">
    <input type="text" id="searchInput" class="sc-search" placeholder="Buscar por título o CVE…">
    <select id="filterFixed" class="sc-select">
      <option value="all">Mostrar todas</option>
      <option value="fixed">Corregidas</option>
      <option value="notfixed">No corregidas</option>
      <option value="unknown">No se conoce si está corregida</option>
    </select>
    <select id="filterType" class="sc-select">
      <option value="all">Todos los tipos</option>
      <?php foreach ($types as $type): ?>
        <option value="<?php echo esc_attr($type); ?>"><?php echo esc_html(ucfirst($type)); ?></option>
      <?php endforeach; ?>
    </select>
  </div>

  <?php if (!empty($vulnerabilities)): ?>
    <ul id="vulnList" class="vuln-list">
      <?php foreach ($vulnerabilities as $vuln): ?>
        <?php 
        $props = $vuln->getProperties();

        if (isset($props['fixed_in'])) {
            if ($props['fixed_in'] === '' || $props['fixed_in'] === null) {
                $fixed_status = 'unknown';
            } else {
                $fixed_status = 'fixed';
            }
        } else {
            $fixed_status = 'notfixed';
        }

        $type = strtolower(trim($props['vuln_type'] ?? 'desconocido'));

        $cve_raw = $props['cve'] ?? '';
        if (is_array($cve_raw) || $cve_raw instanceof \Traversable) {
            $cve_array = ($cve_raw instanceof \Traversable) ? iterator_to_array($cve_raw) : $cve_raw;
            $cve_string = implode(', ', $cve_array);
        } else {
            $cve_string = (string)$cve_raw;
        }

        $title = $props['title'] ?? '';
        ?>
        <li class="vuln-item"
            data-title="<?php echo esc_attr(strtolower($title)); ?>"
            data-cve="<?php echo esc_attr(strtolower($cve_string)); ?>"
            data-fixed="<?php echo esc_attr($fixed_status); ?>"
            data-vuln_type="<?php echo esc_attr($type); ?>">

          <strong><?php echo esc_html($title ?: 'Sin título'); ?></strong>
          <?php if ($cve_string): ?> (CVE: <?php echo esc_html($cve_string); ?>)<?php endif; ?><br>

          <?php if (!empty($props['description'])): ?>
            <em><?php echo esc_html($props['description']); ?></em><br>
          <?php endif; ?>

          <?php if ($fixed_status === 'fixed'): ?>
            <small><em>Corregida desde la versión: <?php echo esc_html($props['fixed_in']); ?></em></small>
          <?php elseif ($fixed_status === 'unknown'): ?>
            <small><em>No se conoce si está corregida.</em></small>
          <?php else: ?>
            <small><em>No corregida.</em></small>
          <?php endif; ?>
        </li>
      <?php endforeach; ?>
    </ul>
  <?php else: ?>
    <p class="sc-empty">No se han encontrado vulnerabilidades para esta versión.</p>
  <?php endif; ?>
</div>

<script>
(function(){
  const searchInput = document.getElementById('searchInput');
  const filterFixed = document.getElementById('filterFixed');
  const filterType  = document.getElementById('filterType');
  const vulnItems   = document.querySelectorAll('.vuln-item');

  function filterVulns() {
    const term  = searchInput.value.toLowerCase();
    const fFix  = filterFixed.value;
    const fType = filterType.value;

    vulnItems.forEach(item => {
      const title = item.dataset.title;
      const cve   = item.dataset.cve;
      const fix   = item.dataset.fixed;
      const type  = item.dataset.vuln_type;

      const okSearch = title.includes(term) || cve.includes(term);
      const okFix    = (fFix  === 'all') || (fix  === fFix);
      const okType   = (fType === 'all') || (type === fType);

      item.style.display = (okSearch && okFix && okType) ? '' : 'none';
    });
  }

  searchInput.addEventListener('input', filterVulns);
  filterFixed.addEventListener('change', filterVulns);
  filterType.addEventListener('change',  filterVulns);

  filterVulns();
})();
</script>

<?php include __DIR__ . '/footer.php'; ?>
