<?php
require_once plugin_dir_path(__FILE__) . '/../Neo4jConnector.php';
use SecurityChecker\Neo4jConnector;


if (!function_exists('get_plugins')) {
    require_once ABSPATH . 'wp-admin/includes/plugin.php';
}

$slug = $_GET['plugin'] ?? null;
if (!$slug) {
    echo "<p class='sc-error'>Plugin no especificado.</p>";
    return;
}

try {
    $client = Neo4jConnector::getClient();

    $query = "MATCH (p:Plugin {slug: \$slug}) 
              OPTIONAL MATCH (p)-[:HAS_VULNERABILITY]->(v:Vulnerability)
              RETURN p, collect(v) AS vulns";

    $result = $client->run($query, ['slug' => $slug]);

    if ($result->count() === 0) {
        echo "<p class='sc-error'>Plugin no encontrado en la base de datos.</p>";
        return;
    }

    $record = $result->first();
    $p = $record->get('p');
    $vulns = $record->get('vulns');

    function get_prop($node, $key, $default = 'N/A') {
        if (method_exists($node, 'getProperties')) {
            $props = $node->getProperties();
            if (isset($props[$key]) && $props[$key] !== '') {
                return $props[$key];
            }
        } elseif (is_array($node) && isset($node[$key])) {
            return $node[$key];
        }
        return $default;
    }

    $installed_plugins = get_plugins();
    $installed_version = 'N/A';
    $plugin_active = false;
    $active_plugins = get_option('active_plugins', []);

    foreach ($installed_plugins as $file => $data) {
        $plugin_slug = strtolower(str_replace(' ', '-', $data['Name']));
        if ($plugin_slug === $slug) {
            $installed_version = $data['Version'] ?? 'N/A';
            $plugin_active = in_array($file, $active_plugins, true);
            break;
        }
    }

    $plugin_name = get_prop($p, 'name', $slug);
    $plugin_description = get_prop($p, 'short_description', 'No se encuentra descripción en la base de datos.');
    $plugin_homepage = get_prop($p, 'homepage', null);
    $plugin_updated = get_prop($p, 'last_updated', null);

    $prepared_vulns = [];
    foreach ($vulns as $v) {
        $vprops = $v->getProperties();
        $cve_raw = $vprops['cve'] ?? '';
        if (is_array($cve_raw) || $cve_raw instanceof \Traversable) {
            $cve_array = ($cve_raw instanceof \Traversable) ? iterator_to_array($cve_raw) : $cve_raw;
            $cve_string = implode(', ', $cve_array);
        } else {
            $cve_string = (string)$cve_raw;
        }
        $importance = null;
        if (!empty($vprops['cvss_score'])) {
            $importance = floatval($vprops['cvss_score']);
        } elseif (!empty($vprops['severity'])) {
            $importance = $vprops['severity'];
        }

        $importance_value = 0;
        if (is_numeric($importance)) {
            $importance_value = floatval($importance);
        } elseif (is_string($importance)) {
            $map = ['low'=>1, 'medium'=>5, 'high'=>8, 'critical'=>10];
            $importance_value = $map[strtolower($importance)] ?? 0;
        }

        $prepared_vulns[] = [
            'node' => $v,
            'title' => $vprops['title'] ?? 'Sin título',
            'description' => $vprops['description'] ?? '',
            'cve' => $cve_string,
            'vuln_type' => strtolower($vprops['vuln_type'] ?? 'Desconocido'),
            'importance' => $importance,
            'importance_value' => $importance_value,
        ];
    }

    usort($prepared_vulns, function($a, $b) {
        return $b['importance_value'] <=> $a['importance_value'];
    });

    $vuln_types = [];
    foreach ($prepared_vulns as $vuln) {
        if (!in_array($vuln['vuln_type'], $vuln_types)) {
            $vuln_types[] = $vuln['vuln_type'];
        }
    }
    sort($vuln_types);
} catch (RuntimeException $e) {
    echo '<p class="sc-error">La base de datos está desconectada.</p>';
    return;
}
?>

<div class="wrap sc-wrap">
  <h2 class="sc-title text-center"><?php echo esc_html($plugin_name); ?></h2>

  <p>
    <strong>Versión:</strong> <?php echo esc_html($installed_version); ?> 
    &nbsp;&nbsp;|&nbsp;&nbsp; 
    <strong>Estado:</strong> 
    <span style="color: <?php echo $plugin_active ? '#3c763d' : '#a94442'; ?>; font-weight: 600;">
      <?php echo $plugin_active ? 'Activo' : 'Desactivado'; ?>
    </span>
  </p>

  <p>
    <strong>Última actualización:</strong> 
    <?php echo $plugin_updated ? esc_html(date_i18n('d/m/Y', strtotime($plugin_updated))) : 'No disponible'; ?>
  </p>

  <p><strong>Descripción:</strong> <?php echo esc_html($plugin_description); ?></p>
  <p><strong>Enlace:</strong> 
    <?php if ($plugin_homepage): ?>
      <a href="<?php echo esc_url($plugin_homepage); ?>" target="_blank" rel="noopener noreferrer">
        <?php echo esc_html($plugin_homepage); ?>
      </a>
    <?php else: ?>
      No disponible
    <?php endif; ?>
  </p>

  <h3>Vulnerabilidades</h3>

  <?php if (!empty($prepared_vulns)): ?>
    <div class="mb-3 d-flex gap-2 justify-content-center flex-wrap">
      <input type="text" id="searchVulns" class="form-control" placeholder="Buscar vulnerabilidades..." style="max-width: 300px;">
      <select id="filterVulnType" class="sc-select" style="max-width: 200px;">
        <option value="all">Todos los tipos</option>
        <?php foreach ($vuln_types as $type): ?>
          <option value="<?php echo esc_attr($type); ?>"><?php echo esc_html(ucfirst($type)); ?></option>
        <?php endforeach; ?>
      </select>
      <select id="sortImportance" class="sc-select" style="max-width: 200px;">
        <option value="desc" selected>Ordenar por importancia (mayor primero)</option>
        <option value="asc">Ordenar por importancia (menor primero)</option>
      </select>
    </div>

    <ul class="sc-list" id="vulnList">
      <?php foreach ($prepared_vulns as $v): ?>
        <li class="sc-list-item" data-title="<?php echo esc_attr(strtolower($v['title'])); ?>" data-type="<?php echo esc_attr($v['vuln_type']); ?>" data-importance="<?php echo esc_attr($v['importance_value']); ?>">
          <strong><?php echo esc_html($v['title']); ?></strong> 
          <strong>CVE:</strong> <?php echo esc_html($v['cve']); ?> 
          <strong>Tipo:</strong> <?php echo esc_html(ucfirst($v['vuln_type'])); ?>  
          <strong>Importancia:</strong> <?php echo esc_html(is_numeric($v['importance']) ? $v['importance'] : ucfirst($v['importance'])); ?>
          <?php if ($v['description'] !== ''): ?>
            <br><em><?php echo esc_html($v['description']); ?></em>
          <?php endif; ?>
        </li>
      <?php endforeach; ?>
    </ul>
  <?php else: ?>
    <p class="sc-empty">No se han detectado vulnerabilidades para este plugin.</p>
  <?php endif; ?>

  <?php include __DIR__ . '/footer.php'; ?>
</div>

<script>
  (function(){
    const searchInput = document.getElementById('searchVulns');
    const filterType = document.getElementById('filterVulnType');
    const sortImportance = document.getElementById('sortImportance');
    const vulnList = document.getElementById('vulnList');
    let vulnItems = Array.from(vulnList.querySelectorAll('li.sc-list-item'));

    function renderList(items) {
      vulnList.innerHTML = '';
      items.forEach(item => vulnList.appendChild(item));
    }

    function filterAndSort() {
      const searchTerm = searchInput.value.toLowerCase();
      const selectedType = filterType.value;
      const sortOrder = sortImportance.value;

      let filtered = vulnItems.filter(item => {
        const title = item.getAttribute('data-title');
        const type = item.getAttribute('data-type');
        const matchesSearch = title.includes(searchTerm);
        const matchesType = (selectedType === 'all') || (type === selectedType);
        return matchesSearch && matchesType;
      });

      filtered.sort((a, b) => {
        const aVal = parseFloat(a.getAttribute('data-importance')) || 0;
        const bVal = parseFloat(b.getAttribute('data-importance')) || 0;
        return sortOrder === 'asc' ? aVal - bVal : bVal - aVal;
      });

      renderList(filtered);
    }

    searchInput.addEventListener('input', filterAndSort);
    filterType.addEventListener('change', filterAndSort);
    sortImportance.addEventListener('change', filterAndSort);

    filterAndSort();
  })();
</script>
