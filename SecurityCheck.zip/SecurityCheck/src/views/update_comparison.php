<?php
require_once plugin_dir_path(__FILE__) . '/../Neo4jConnector.php';
use SecurityChecker\Neo4jConnector;

$client = Neo4jConnector::getClient();
$current_version = get_bloginfo('version');
$target_version = $_GET['target_version'] ?? '';

if (!$target_version) {
    echo '<p class="sc-error">No se ha seleccionado ninguna versión objetivo.</p>';
    return;
}

try {
    $vuln_query = "MATCH (w:WordPressVersion {version: \$version}) 
                   OPTIONAL MATCH (w)-[:HAS_VULNERABILITY]->(v:Vulnerability)
                   RETURN collect(v) AS vulnerabilities";

    $current_vuln_result = $client->run($vuln_query, ['version' => $current_version]);
    $target_vuln_result  = $client->run($vuln_query, ['version' => $target_version]);
} catch (Exception $e) {
    echo '<p class="sc-error">Error al consultar la base de datos: ' . esc_html($e->getMessage()) . '</p>';
    return;
}

$current_vulns = $current_vuln_result->first()['vulnerabilities'] ?? [];
$target_vulns  = $target_vuln_result->first()['vulnerabilities'] ?? [];

$new_vulns = [];
$current_ids = [];
$vuln_types = [];

foreach ($current_vulns as $v) {
    if ($v && isset($v['id'])) {
        $current_ids[] = $v['id'];
    }
}
foreach ($target_vulns as $v) {
    if ($v && isset($v['id']) && !in_array($v['id'], $current_ids)) {
        $new_vulns[] = $v;
        $props = $v->getProperties();
        if (!empty($props['vuln_type'])) {
            $vuln_types[] = strtolower($props['vuln_type']);
        }
    }
}
$vuln_types = array_unique($vuln_types);
sort($vuln_types);

if (!function_exists('get_plugins')) {
    require_once ABSPATH . 'wp-admin/includes/plugin.php';
}

$installed_plugins = get_plugins();
$lost_plugins = [];
$gained_plugins = [];
$missing_plugins = [];

foreach ($installed_plugins as $plugin_file => $plugin_data) {
    $plugin_slug = strtolower(str_replace(' ', '-', $plugin_data['Name']));

    if ($plugin_slug === 'securitychecker') continue;

    try {
        $check_query = "MATCH (p:Plugin {slug: \$slug}) RETURN p.slug LIMIT 1";
        $check_result = $client->run($check_query, ['slug' => $plugin_slug]);

        if ($check_result->count() === 0) {
            $missing_plugins[] = $plugin_slug;
            continue;
        }

        $compat_query = "MATCH (p:Plugin {slug: \$slug}), (w:WordPressVersion {version: \$version})
                         RETURN EXISTS((p)-[:IS_COMPATIBLE]->(w)) AS compatible";

        $current_compat = $client->run($compat_query, ['slug' => $plugin_slug, 'version' => $current_version]);
        $current_compatible = $current_compat->first()['compatible'];

        $target_compat = $client->run($compat_query, ['slug' => $plugin_slug, 'version' => $target_version]);
        $target_compatible = $target_compat->first()['compatible'];

        if ($current_compatible && !$target_compatible) {
            $lost_plugins[] = $plugin_slug;
        } elseif (!$current_compatible && $target_compatible) {
            $gained_plugins[] = $plugin_slug;
        }
    } catch (Exception $e) {
        error_log('Neo4j query failed in update_comparison.php for plugin ' . $plugin_slug . ': ' . $e->getMessage());
    }
}
?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<div class="wrap sc-wrap container">
  <h2 class="sc-title text-center my-4">
    Comparación: versión actual (<?php echo esc_html($current_version); ?>) vs objetivo (<?php echo esc_html($target_version); ?>)
  </h2>

  <div class="row">

    <div class="col-md-6">
      <h3>Nuevas vulnerabilidades en la versión objetivo</h3>

      <div class="d-flex gap-2 mb-3">
        <input type="text" id="searchNewVulns" class="sc-search form-control" placeholder="Buscar vulnerabilidades...">
        <select id="filterVulnType" class="sc-select form-select" style="max-width: 200px;" aria-label="Filtrar por tipo de vulnerabilidad">
           <option value="all" selected>Todos los tipos</option>
          <?php foreach ($vuln_types as $type): ?>
            <option value="<?php echo esc_attr($type); ?>"><?php echo esc_html(ucfirst($type)); ?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <?php if (!empty($new_vulns)): ?>
        <ul id="list-new_vulns" class="sc-list">
          <?php foreach ($new_vulns as $v): 
            $props = $v->getProperties();
            $vuln_type = strtolower($props['vuln_type'] ?? '');
          ?>
            <li data-type="<?php echo esc_attr($vuln_type); ?>"><?php echo esc_html($props['title'] ?? 'Sin título'); ?></li>
          <?php endforeach; ?>
        </ul>
      <?php else: ?>
        <p class="sc-empty">No se detectan nuevas vulnerabilidades.</p>
      <?php endif; ?>
    </div>

    <div class="col-md-6">
      <h3>Plugins ganados al actualizar</h3>
      <input type="text" id="searchGained" class="sc-search form-control mb-3" placeholder="Buscar plugins ganados...">
      <?php if (!empty($gained_plugins)): ?>
        <ul id="list-gained_plugins" class="sc-list mb-4">
          <?php foreach ($gained_plugins as $p): ?>
            <li>
              <?php echo esc_html($p); ?>
              <a href="?page=security_checker&view=plugin_view&plugin=<?php echo urlencode($p); ?>" class="sc-plugin-button ms-3">
                Ver plugin
              </a>
            </li>
          <?php endforeach; ?>
        </ul>
      <?php else: ?>
        <p class="sc-empty mb-4">No se ganan nuevos plugins.</p>
      <?php endif; ?>

      <h3>Plugins perdidos al actualizar</h3>
      <input type="text" id="searchLost" class="sc-search form-control mb-3" placeholder="Buscar plugins perdidos...">
      <?php if (!empty($lost_plugins)): ?>
        <ul id="list-lost_plugins" class="sc-list mb-4">
          <?php foreach ($lost_plugins as $p): ?>
            <li>
              <?php echo esc_html($p); ?>
              <a href="?page=security_checker&view=plugin_view&plugin=<?php echo urlencode($p); ?>" class="sc-plugin-button ms-3">
                Ver plugin
              </a>
            </li>
          <?php endforeach; ?>
        </ul>
      <?php else: ?>
        <p class="sc-empty mb-4">No se pierden plugins.</p>
      <?php endif; ?>

      <h3>Plugins no encontrados en la API (o con otro nombre)</h3>
      <input type="text" id="searchMissing" class="sc-search form-control mb-3" placeholder="Buscar plugins no encontrados...">
      <?php if (!empty($missing_plugins)): ?>
        <ul id="list-missing_plugins" class="sc-list">
          <?php foreach ($missing_plugins as $p): ?>
            <li><?php echo esc_html($p); ?></li>
          <?php endforeach; ?>
        </ul>
      <?php else: ?>
        <p class="sc-empty">Todos los plugins están presentes en la base de datos.</p>
      <?php endif; ?>
    </div>
  </div>
</div>

<script>
  function filterList(inputId, listId, extraFilterFunc = null) {
    const input = document.getElementById(inputId);
    const list = document.getElementById(listId);
    if (!input || !list) return;
    input.addEventListener('input', () => {
      const filter = input.value.toLowerCase();
      const items = list.getElementsByTagName('li');
      Array.from(items).forEach(item => {
        const text = item.textContent.toLowerCase();
        const extraOk = extraFilterFunc ? extraFilterFunc(item) : true;
        item.style.display = (text.includes(filter) && extraOk) ? '' : 'none';
      });
    });
  }

  document.addEventListener('DOMContentLoaded', () => {
    const vulnTypeSelect = document.getElementById('filterVulnType');
    const vulnSearch = document.getElementById('searchNewVulns');
    filterList('searchNewVulns', 'list-new_vulns', (item) => {
      const selectedType = vulnTypeSelect.value;
      if (selectedType === 'all') return true;
      return item.getAttribute('data-type') === selectedType;
    });
    vulnTypeSelect.addEventListener('change', () => vulnSearch.dispatchEvent(new Event('input')));

    filterList('searchGained', 'list-gained_plugins');
    filterList('searchLost', 'list-lost_plugins');
    filterList('searchMissing', 'list-missing_plugins');
  });
</script>
