<?php
$current_view = $_GET['view'] ?? 'home';
?>
<div class="sc-footer">
  <?php if ($current_view !== 'home'): ?>
    <button onclick="window.location.href='?page=security_checker&view=home'">Menú principal</button>
  <?php endif; ?>

  <?php if ($current_view !== 'plugins_list'): ?>
    <button onclick="window.location.href='?page=security_checker&view=plugins_list'">Plugins actuales instalados</button>
  <?php endif; ?>

  <?php if ($current_view !== 'vulnerable_plugins'): ?>
    <button onclick="window.location.href='?page=security_checker&view=vulnerable_plugins'">Plugins vulnerables</button>
  <?php endif; ?>

  <?php if ($current_view !== 'vulnerabilities'): ?>
    <button onclick="window.location.href='?page=security_checker&view=vulnerabilities'">Vulnerabilidades de la versión</button>
  <?php endif; ?>
  
  <?php if ($current_view === 'plugin_view' && !empty($_GET['plugin'])): ?>
    <button onclick="history.back()">Volver</button>
  <?php endif; ?>
</div>
