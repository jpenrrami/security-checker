<?php
require_once plugin_dir_path(__FILE__) . '/../Neo4jConnector.php';
use SecurityChecker\Neo4jConnector;

try {
    $client  = Neo4jConnector::getClient();
    $version = get_bloginfo('version');

    $query  = "MATCH (w:WordPressVersion) RETURN w.version AS version ORDER BY w.version DESC";
    $result = $client->run($query);

    $versions = [];
    foreach ($result as $record) {
      $versions[] = $record->get('version');
    }

    $typeQuery   = "MATCH (v:Vulnerability) RETURN v.vuln_type AS type, count(*) AS count ORDER BY count DESC";
    $typeResult  = $client->run($typeQuery);

    $types  = [];
    $counts = [];
    foreach ($typeResult as $rec) {
      $types[]  = $rec->get('type')  ?? 'Desconocido';
      $counts[] = (int)$rec->get('count');
    }

    $types_json  = json_encode($types);
    $counts_json = json_encode($counts);
    $total_vulnerabilities = array_sum($counts);
} catch (RuntimeException $e) {
    echo '<p style="color:red; font-weight:bold; max-width: 600px; margin: 20px auto;">La base de datos está desconectada.</p>';
    return;
}
?>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<div class="wrap sc-wrap">
  <h1 class="sc-title">Security Checker</h1>
  <p class="sc-sub">Número total de vulnerabilidades: <strong><?php echo $total_vulnerabilities ?? 0; ?></strong></p>
  <h3 class="sc-sub">Esta es la distribución del tipo de tus vulnerabilidades</h3>
  <div class="sc-chart-container">
    <canvas id="vulnTypeChart"></canvas>
  </div>

  <script>
  document.addEventListener('DOMContentLoaded', function() {
    const ctx = document.getElementById('vulnTypeChart').getContext('2d');
    new Chart(ctx, {
      type: 'pie',
      data: {
        labels: <?php echo $types_json ?? '[]'; ?>,
        datasets: [{ 
          data: <?php echo $counts_json ?? '[]'; ?>,
          backgroundColor: [
            '#FF6384','#36A2EB','#FFCE56','#4BC0C0',
            '#9966FF','#FF9F40','#C9CBCF','#FF6666',
            '#66FF66','#6666FF'
          ], hoverOffset:30 
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { position:'bottom' },
          tooltip: {
            callbacks: {
              label(ctx) {
                const v = ctx.parsed, t = ctx.label;
                const tot = ctx.chart._metasets[ctx.datasetIndex].total;
                const pct = ((v/tot)*100).toFixed(2);
                return `${t}: ${v} (${pct}%)`;
              }
            }
          }
        }
      }
    });
  });
  </script>

  <h3 class="sc-sub">Seleccione aquí a qué versión le gustaría simular la actualización</h3>

  <form method="get" action="" class="sc-form">
    <input type="hidden" name="page" value="security_checker">
    <input type="hidden" name="view" value="update_comparison">
    <select name="target_version" class="sc-select">
      <?php foreach ($versions ?? [] as $v): ?>
        <option value="<?php echo esc_attr($v); ?>"><?php echo esc_html($v); ?></option>
      <?php endforeach; ?>
    </select>
    <button type="submit" class="sc-button">🔍</button>
  </form>

  <p class="sc-sub">
    Actualmente está usted en la versión <strong><?php echo esc_html($version ?? 'N/A'); ?></strong>
  </p>
</div>

<?php include __DIR__ . '/footer.php'; ?>
