<?php
/**
 * Plugin Name: Security Checker
 * Description: Analiza vulnerabilidades en versiones de WordPress y plugins instalados.
 * Version: 1.0
 * Author: Jose Manuel Peña Ramirez
 */

if (!defined('ABSPATH')) {
    exit;
}

require_once plugin_dir_path(__FILE__) . 'src/functions.php';
require_once plugin_dir_path(__FILE__) . 'vendor/autoload.php';

add_action('admin_menu', function () {
    add_menu_page(
        'Security Checker',
        'Security Checker',
        'manage_options',
        'security_checker', // Siempre será page=security_checker
        'security_checker_router'
    );
});

add_action('admin_enqueue_scripts', function () {

    /* Chart.js */
    wp_enqueue_script(
        'chart-js',
        'https://cdn.jsdelivr.net/npm/chart.js',
        [],
        null,
        true
    );

    /* CSS del plugin */
    wp_enqueue_style(
        'sc-estilos',
        plugins_url('src/assets/estilos.css', __FILE__), 
        [],
        null
    );
});




function security_checker_router() {
    $view = $_GET['view'] ?? 'home';

    switch ($view) {
        case 'vulnerabilities':
            include plugin_dir_path(__FILE__) . 'src/views/vulnerabilities.php';
            break;
        case 'plugins_list':
            include plugin_dir_path(__FILE__) . 'src/views/plugins_list.php';
            break;
        case 'vulnerable_plugins':
            include plugin_dir_path(__FILE__) . 'src/views/vulnerable_plugins.php';
            break;
        case 'plugin_view':
            include plugin_dir_path(__FILE__) . 'src/views/plugin_view.php';
            break;
        case 'update_comparison':
            include plugin_dir_path(__FILE__) . 'src/views/update_comparison.php';
            break;
        default:
            include plugin_dir_path(__FILE__) . 'src/views/home.php';
            break;
    }
}